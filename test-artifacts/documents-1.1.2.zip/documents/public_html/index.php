<?php

/* Reminder: always indent with 4 spaces (no tabs). */
// +---------------------------------------------------------------------------+
// | Documents Plugin 1.1.2                                                    |
// +---------------------------------------------------------------------------+
// | index.php                                                                 |
// |                                                                           |
// | Public plugin page.                                                       |
// +---------------------------------------------------------------------------+
// | Copyright (C) 2012-2026 by the following authors:                         |
// |                                                                           |
// | Authors: Ben - ben AT geeklog DOT fr                                      |
// |          Documents plugin contributors                                    |
// +---------------------------------------------------------------------------+
// |                                                                           |
// | This program is free software; you can redistribute it and/or             |
// | modify it under the terms of the GNU General Public License               |
// | as published by the Free Software Foundation; either version 2            |
// | of the License, or (at your option) any later version.                    |
// +---------------------------------------------------------------------------+

/**
 * @package Documents
 */

require_once '../lib-common.php';

if (!isset($_PLUGINS) || !is_array($_PLUGINS) || !in_array('documents', $_PLUGINS, true)) {
    echo COM_refresh($_CONF['site_url'] . '/index.php');
    exit;
}

require_once $_CONF['path'] . 'plugins/documents/rewrite.php';
DOCUMENTS_writeHtaccess(false);

require_once $_CONF['path'] . 'plugins/documents/runtime.php';
DOCUMENTS_ensureImageDirectory();

require_once $_CONF['path'] . 'plugins/documents/include_compat.php';
require_once $_CONF['path'] . 'plugins/documents/integrity.php';
DOCUMENTS_initializeRequestDefaults($_REQUEST);

$documentsMode = (string) DOCUMENTS_requestValue($_REQUEST, 'mode', '');
$documentsDocUrl = (string) DOCUMENTS_requestValue($_REQUEST, 'doc_url', '');
$documentsOperation = (string) DOCUMENTS_requestValue($_REQUEST, 'op', '');

// Administrative write operations must never reach the legacy controller
// without Documents Admin rights, even if a future handler forgets its own
// local check.
$documentsAdminWriteModes = array('save_cat', 'save_field', 'save_group', 'save_select');
if (in_array($documentsMode, $documentsAdminWriteModes, true)
    && !SEC_hasRights('documents.admin')) {
    echo COM_refresh($_CONF['site_url'] . '/404.php');
    exit;
}

if ($documentsMode === 'save_cat') {
    $_REQUEST['cat_url'] = DOCUMENTS_normalizeRouteSlug(
        DOCUMENTS_requestValue($_REQUEST, 'cat_url', '')
    );
    $_POST['cat_url'] = $_REQUEST['cat_url'];
}

// Prepare a collision-safe URL before the legacy save controller starts a new
// document. The controller keeps the historical numeric-prefix format, but if
// DOC_URL is already defined it reuses this validated candidate.
if ($documentsMode === 'save' && $documentsDocUrl === '' && $documentsOperation !== 'delete') {
    $documentsCid = DOCUMENTS_requestInt($_REQUEST, 'cid', 0);
    if ($documentsCid > 0) {
        $firstField = DB_query(
            "SELECT var_name FROM {$_TABLES['documents_fields']} "
            . "WHERE cat_id={$documentsCid} ORDER BY f_order ASC, fid ASC LIMIT 1"
        );
        $firstFieldRow = DB_fetchArray($firstField);
        if (is_array($firstFieldRow) && !empty($firstFieldRow['var_name'])) {
            $titleValue = DOCUMENTS_requestValue($_REQUEST, $firstFieldRow['var_name'], '');
            if (is_array($titleValue)) {
                $titleValue = '';
            }
            if (!defined('DOC_URL')) {
                define('DOC_URL', DOCUMENTS_uniqueDocumentUrl((string) $titleValue));
            }
        }
    }
}

if ($documentsMode === 'save' && $documentsDocUrl !== '' && $documentsOperation !== 'delete') {
    $documentsImagesBeforeSave = DOCUMENTS_documentImageReferences($documentsDocUrl);
    if (!empty($documentsImagesBeforeSave)) {
        register_shutdown_function(
            'DOCUMENTS_cleanupReplacedImages',
            $documentsImagesBeforeSave,
            $documentsDocUrl
        );
    }
}

if ($documentsMode === 'save' && $documentsDocUrl !== '' && $documentsOperation === 'delete') {
    $documentsImagesBeforeDelete = DOCUMENTS_documentImageReferences($documentsDocUrl);
    register_shutdown_function(
        'DOCUMENTS_cleanupDeletedDocumentImages',
        $documentsDocUrl,
        $documentsImagesBeforeDelete
    );
}

if ($documentsMode === 'save_field' && $documentsOperation === 'delete') {
    $documentsFieldId = DOCUMENTS_requestInt($_REQUEST, 'fid', 0);
    if ($documentsFieldId > 0) {
        $documentsFieldImages = DOCUMENTS_fieldImageReferences($documentsFieldId);
        if (!empty($documentsFieldImages)) {
            register_shutdown_function(
                'DOCUMENTS_cleanupDeletedFieldImages',
                $documentsFieldId,
                $documentsFieldImages
            );
        }
    }
}

$requestPath = isset($_SERVER['REQUEST_URI'])
    ? parse_url((string) $_SERVER['REQUEST_URI'], PHP_URL_PATH)
    : '';
if (is_string($requestPath) && preg_match('#/index\.php$#', $requestPath)) {
    $mode = (string) DOCUMENTS_requestValue($_REQUEST, 'mode', '');
    $catUrl = (string) DOCUMENTS_requestValue($_REQUEST, 'cat', '');
    $docUrl = (string) DOCUMENTS_requestValue($_REQUEST, 'doc', '');

    if ($mode === 'view' && $catUrl !== '') {
        $canonical = rtrim((string) $_DOCUMENTS_CONF['site_url'], '/')
            . '/' . rawurlencode($catUrl);
        if ($docUrl !== '') {
            $canonical .= '/' . rawurlencode($docUrl);
        }
        header('Location: ' . $canonical, true, 301);
        exit;
    }
}

require_once $_CONF['path'] . 'plugins/documents/include_html.php';
