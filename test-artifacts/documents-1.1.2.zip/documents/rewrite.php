<?php

/* Reminder: always indent with 4 spaces (no tabs). */
// +---------------------------------------------------------------------------+
// | Documents Plugin 1.1.2                                                    |
// +---------------------------------------------------------------------------+
// | rewrite.php                                                               |
// |                                                                           |
// | Creates and refreshes the public .htaccess rewrite rules.                 |
// +---------------------------------------------------------------------------+

/**
 * @package Documents
 */

if (!function_exists('DOCUMENTS_writeHtaccess')) {
    /**
     * Create or refresh the Documents .htaccess file.
     *
     * Normal runtime calls use $force=false and only repair a missing file.
     * Installation/update calls use $force=true so the current plugin rules
     * replace rules shipped by an older Documents release.
     *
     * @param bool $force Rewrite an existing file when true
     * @return bool
     */
    function DOCUMENTS_writeHtaccess($force = false)
    {
        global $_CONF, $_DOCUMENTS_CONF;

        if (isset($_DOCUMENTS_CONF['path_html']) && $_DOCUMENTS_CONF['path_html'] !== '') {
            $publicDir = rtrim($_DOCUMENTS_CONF['path_html'], "/\\") . DIRECTORY_SEPARATOR;
        } else {
            $folder = isset($_DOCUMENTS_CONF['documents_folder'])
                ? trim($_DOCUMENTS_CONF['documents_folder'], "/\\")
                : 'documents';
            $publicDir = rtrim($_CONF['path_html'], "/\\") . DIRECTORY_SEPARATOR
                . $folder . DIRECTORY_SEPARATOR;
        }

        if (!is_dir($publicDir)) {
            if (function_exists('COM_errorLog')) {
                COM_errorLog('Documents rewrite: public directory not found at ' . $publicDir);
            }
            return false;
        }

        $target = $publicDir . '.htaccess';
        if (!$force && is_file($target)) {
            return true;
        }

        $siteUrl = isset($_DOCUMENTS_CONF['site_url'])
            ? rtrim((string) $_DOCUMENTS_CONF['site_url'], '/')
            : '';
        $urlBase = $siteUrl !== '' ? parse_url($siteUrl, PHP_URL_PATH) : '';
        if (!is_string($urlBase) || $urlBase === '') {
            $folder = isset($_DOCUMENTS_CONF['documents_folder'])
                ? trim($_DOCUMENTS_CONF['documents_folder'], "/\\")
                : 'documents';
            $urlBase = '/' . $folder;
        }
        if ($urlBase[0] !== '/') {
            $urlBase = '/' . $urlBase;
        }
        $urlBase = rtrim($urlBase, '/');

        $rules = "RewriteEngine On\n\n"
            // Canonicalize explicit document URLs to the historical pretty URL.
            . "RewriteCond %{THE_REQUEST} \\s[^?\\s]*index\\.php\\?mode=view&cat=([^&\\s]+)&doc=([^&\\s]+) [NC]\n"
            . "RewriteRule ^index\\.php$ " . $urlBase . "/%1/%2? [R=301,L,NE]\n\n"
            // Canonicalize explicit category URLs.
            . "RewriteCond %{THE_REQUEST} \\s[^?\\s]*index\\.php\\?mode=view&cat=([^&\\s]+) [NC]\n"
            . "RewriteRule ^index\\.php$ " . $urlBase . "/%1? [R=301,L,NE]\n\n"
            // Pretty document URL -> internal request.
            . "RewriteCond %{REQUEST_FILENAME} !-f\n"
            . "RewriteCond %{REQUEST_FILENAME} !-d\n"
            . "RewriteRule ^([^/]+)/([^/]+)/?$ index.php?mode=view&cat=$1&doc=$2 [L,QSA]\n\n"
            // Pretty category URL -> internal request.
            . "RewriteCond %{REQUEST_FILENAME} !-f\n"
            . "RewriteCond %{REQUEST_FILENAME} !-d\n"
            . "RewriteRule ^([^/]+)/?$ index.php?mode=view&cat=$1 [L,QSA]\n";

        if (@file_put_contents($target, $rules, LOCK_EX) === false) {
            if (function_exists('COM_errorLog')) {
                COM_errorLog('Documents rewrite: unable to write ' . $target);
            }
            return false;
        }

        return true;
    }
}
